from typing import Generator
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from pydantic import ValidationError
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.db import models
from app.api.v1.schemas import token as schemas_token
from app.core.config import settings
from app.core.exceptions import CREDENTIALS_EXCEPTION, INACTIVE_USER_EXCEPTION, USER_NOT_FOUND_EXCEPTION


oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_STR}/auth/login")

def get_current_user(
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
) -> models.User:
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        token_data = schemas_token.TokenPayload(**payload)
    except (JWTError, ValidationError):
        raise CREDENTIALS_EXCEPTION

    user = db.query(models.User).filter(models.User.id == token_data.sub).first()
    if not user:
        raise USER_NOT_FOUND_EXCEPTION
    return user


def get_current_active_user(
    current_user: models.User = Depends(get_current_user)
) -> models.User:
    if not current_user.is_active:
        raise INACTIVE_USER_EXCEPTION
    return current_user


def get_current_active_superuser(
    current_user: models.User = Depends(get_current_user)
) -> models.User:
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="The user doesn't have enough privileges"
        )
    return current_user
